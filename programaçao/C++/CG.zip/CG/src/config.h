#pragma once
#include <iostream>
#include <GL/gl.h>
//#include <glad/glad.h>
#include <GLFW/glfw3.h>