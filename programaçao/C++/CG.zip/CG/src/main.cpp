#include "config.h"

int main(){
    GLFWwindow *window;
    if(!glfwInit()){
        std::cout << "GLfW colud't start" << std::endl;
        return -1;
    }

    window = glfwCreateWindow(640,480,"Minha Tela",NULL,NULL);

    glfwMakeContextCurrent(window);

    /*if(!gladLoadGLLoader(GLADloadproc(glfwGetProcAddress))){
        glfwTerminate();
        return -1;
    }*/

    glClearColor(0.0f,0.0f,0.0f,0.0f);

    while(!glfwWindowShouldClose(window)){
        glfwPollEvents();

        glClear(GL_COLOR_BUFFER_BIT);
        //glBind(GL_TRIANGLES);
        
        //glBegin(GL_TRIANGLES);
        glBegin(GL_LINE_LOOP);//start drawing a line loop
      glVertex3f(-1.0f,0.0f,0.0f);//left of window
      glVertex3f(0.0f,-1.0f,0.0f);//bottom of window
      glVertex3f(1.0f,0.0f,0.0f);//right of window
      glVertex3f(0.0f,1.0f,0.0f);//top of window
    glEnd();//end drawing of line loop
        
        glfwSwapBuffers(window);
    }
    
    printf("confirmado\n");
    glfwTerminate();
    return 0;
}