#!/bin/sh  
# a linha acima declara o bin que executará o script
          
clear
#Limpa o terminal
                
ls
#Ve os arquivos

make
#Compila o makefile

./teste
#Roda o executavel do makefile
